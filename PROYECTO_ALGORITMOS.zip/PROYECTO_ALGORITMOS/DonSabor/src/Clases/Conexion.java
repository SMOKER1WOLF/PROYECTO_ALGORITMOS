/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import java.sql.Connection;
import java.sql.DriverManager;
import javax.swing.JOptionPane;

public class Conexion {
    
    Connection con = null;
    
//    String usuario = "userSQL";
//    String pss = "Qwerty123";
//    String bd = "DonSabor";
//    String ip = "localhost";
//    String puerto = "1433";
    
    String conexionUrl = "jdbc:sqlserver://localhost:1433;"
            +"databaseName=DonSabor;"
            +"user=userSQL;"
            +"password=Qwerty123;"
            +"loginTimeout=30;";
    
    public Connection establecerConexion(){
 
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            con = DriverManager.getConnection(conexionUrl+"encrypt=true;trustServerCertificate=true");
        }catch(Exception ex){
            System.out.println(ex.toString());
        }

        return con;
    }
}

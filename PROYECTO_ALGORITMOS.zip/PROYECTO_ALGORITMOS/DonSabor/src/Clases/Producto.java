/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Clases;

import Entidades.EntidadProducto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author ANTHONY
 */
public class Producto {
     
    PreparedStatement ps ;
    ResultSet rs;
    
    
    Conexion con = new Conexion();
    Connection acces;
    
    public EntidadProducto recogerDatos(int id ){
        EntidadProducto ep = new EntidadProducto();
        String sql = "select * from Producto where idProducto = ? ";
        try{
            acces = con.establecerConexion();
            ps = acces.prepareStatement(sql);
            ps.setInt(1,id);
            rs = ps.executeQuery();
                while(rs.next()){
                    ep.setIdProducto(rs.getInt(1));
                    ep.setNombreProducto(rs.getString(2));
                    ep.setDescripcionProducto(rs.getString(3));
                    ep.setPrecioProducto(rs.getDouble(4));

                }
        }catch(Exception e){
            
        }
        return ep;
    }
}
